
#include <fstream>
#include <ros/ros.h>
#include <tf2/utils.h>
#include "tf_utils.hpp"
#include <nav_msgs/Odometry.h>
#include <boost/date_time/posix_time/posix_time.hpp>
#include "../../lazo_cerrado/src/KinematicPositionController.h"
#include <tf2_ros/transform_listener.h>


std::string formatTime(const boost::posix_time::ptime& time, const char* format)
{
  boost::posix_time::time_facet* facet = new boost::posix_time::time_facet();
  facet->format( format );

  std::stringstream stream;
  stream.str("");
  stream.imbue(std::locale(std::locale::classic(), facet));
  stream << time;

  return stream.str();
}

std::string timestamp()
{
  return formatTime(boost::posix_time::second_clock::local_time(), "%Y-%m-%d_%H:%M:%S");
}

class Logger
{
  public:

    Logger(ros::NodeHandle& nh);

  private:
	
	tf2_ros::Buffer buff;
	tf2_ros::TransformListener tfListener_;

    ros::Subscriber robot_pose_sub_, ground_truth_sub_, goal_poses_sub_;

    std::ofstream robot_logfile_, ground_truth_logfile_, goal_poses_logfile_;

  // funciones auxiliares

    void handleRobotPose(const tf2_msgs::TFMessage& msg);

    void handleGroundTruthPose(const tf2_msgs::TFMessage& msg);

    void handleGoalPose(const geometry_msgs::PoseStamped& msg);

};

Logger::Logger(ros::NodeHandle& nh)
  : tfListener_(buff), robot_logfile_( timestamp() + "_poses.log" ), ground_truth_logfile_( timestamp() + "_ground-truth.log" ), goal_poses_logfile_( timestamp() + "_goals.log" )
{
  //robot_pose_sub_ = nh.subscribe("/robot/odometry", 1, &Logger::handleRobotPose, this);
  robot_pose_sub_ = nh.subscribe("/tf", 1, &Logger::handleRobotPose, this);
  ground_truth_sub_ = nh.subscribe("/tf", 1, &Logger::handleGroundTruthPose, this);
  goal_poses_sub_ = nh.subscribe("/goal_pose", 1, &Logger::handleGoalPose, this);
}

void Logger::handleRobotPose(const tf2_msgs::TFMessage& msg)
{
  //robot_logfile_ << msg.header.stamp.toSec() << " " << msg.pose.pose.position.x << " " << msg.pose.pose.position.y << " " << tf2::getYaw( msg.pose.pose.orientation ) << std::endl;
  	if(msg.transforms[0].child_frame_id == "base_link"){

	tf2::Transform ground_truth;
	ros::Time t = ros::Time(msg.transforms[0].header.stamp);

    if(lookupTransformSafe(buff, "map", "base_link", t, ground_truth)){
    	double x = ground_truth.getOrigin().getX();
	  	double y = ground_truth.getOrigin().getY();
	  	double a = tf2::getYaw(ground_truth.getRotation());
	  	std::cout << "-------------------------------------------------" << std::endl;
		std::cout << "-------------------------------------------------" << std::endl;
		std::cout << x << " "<< y << " " << a << std::endl;
		std::cout << "-------------------------------------------------" << std::endl;
		std::cout << "-------------------------------------------------" << std::endl;
	  	  	 
	  	robot_logfile_ << msg.transforms[0].header.stamp << " " << x << " " << y << " " << a << std::endl;
	  } else{
	  	std::cout << "Fail" << std::endl;
	  }
  	}
}

void Logger::handleGroundTruthPose(const tf2_msgs::TFMessage& msg)
{
	
	if(msg.transforms[0].child_frame_id == "base_link_ekf"){

  	tf2::Transform ground_truth;
  	ros::Time t = ros::Time(msg.transforms[0].header.stamp);

    if(lookupTransformSafe(buff, "map", "base_link_ekf", t, ground_truth)){
    	double x = ground_truth.getOrigin().getX();
	  	double y = ground_truth.getOrigin().getY();
	  	double a = tf2::getYaw(ground_truth.getRotation());
	  	std::cout << "-------------------------------------------------" << std::endl;
		std::cout << "-------------------------------------------------" << std::endl;
		std::cout << x << " "<< y << " " << a << std::endl;
		std::cout << "-------------------------------------------------" << std::endl;
		std::cout << "-------------------------------------------------" << std::endl;
	  	  	 
	  ground_truth_logfile_ << msg.transforms[0].header.stamp << " " << x << " " << y << " " << a << std::endl;
	  } else{
	  	std::cout << "Fail" << std::endl;
	  }
  }
  	
}

void Logger::handleGoalPose(const geometry_msgs::PoseStamped& msg)
{
  goal_poses_logfile_ << msg.header.stamp.toSec() << " " << msg.pose.position.x << " " << msg.pose.position.y << " " << tf2::getYaw( msg.pose.orientation ) << std::endl;
}

int main(int argc, char** argv)
{
  ros::init(argc, argv, "logger");
  ros::NodeHandle nh;

  Logger logger( nh );

  ros::spin();

  return 0;
}
