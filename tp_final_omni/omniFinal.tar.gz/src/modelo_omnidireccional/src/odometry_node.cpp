#include <ros/ros.h>
#include "odometry.h"

int main(int argc, char** argv)
{
  ros::init(argc, argv, "odometry");
  ros::NodeHandle nh;
  robmovil::Odometry odometry(nh);
  ros::spin();
  return 0;
}
