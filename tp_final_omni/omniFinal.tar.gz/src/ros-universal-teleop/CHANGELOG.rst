^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package universal_teleop
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.0 (2014-06-08)
------------------
* launch files
* tidy up for release
* added axis scaling; robot now stops after override is released
* launch files for ardrone; changes for ardrone(_autonomy); changed defaults
* fix for hydro
* first version
* Contributors: v01d
