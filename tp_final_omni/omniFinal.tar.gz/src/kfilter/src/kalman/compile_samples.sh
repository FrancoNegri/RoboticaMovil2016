cd samples

cd KVector
make
cd ..

cd KMatrix
make
cd ..

cd EKFilter
make
cd ..

cd Example
make
cd ..

cd ..

